# Project Loom: Library Files

This folder is where all of the Loom Library files live.

If you are looking for the comprehensive readme that used be here, it is now one directory up, now found [here](https://github.com/OPEnSLab-OSU/InternetOfAg)